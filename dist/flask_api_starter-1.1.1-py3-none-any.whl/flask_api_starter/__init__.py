# flask_api_starter package
__version__ = "0.1.0"
